# Tablero de Control para Cazafantasmas
## Nuevas funcionalidades
addGhost
setDangerLevel
captureGhost
